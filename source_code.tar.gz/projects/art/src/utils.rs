use crate::kinds::*;

/// 结合两种等量的主要颜色，创建出
/// 某种次要颜色。
pub fn mix(c1: PrimaryColor, c2: PrimaryColor) -> SecondaryColor {
    // --跳过代码--
    println! ("c1: {:?}, c2: {:?}", c1, c2);
    SecondaryColor::Purple
}
