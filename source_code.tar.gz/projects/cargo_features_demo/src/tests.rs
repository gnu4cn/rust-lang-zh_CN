use super::*;

#[test]
fn five_plus_one() {
    assert_eq! (7, add_one(5));
}
