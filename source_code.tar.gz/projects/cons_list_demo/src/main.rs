#[derive(Debug)]
enum List {
    Cons(Rc<RefCell<i32>>, Rc<List>),
    Nil,
}

use crate::List::{Cons, Nil};
use std::cell::RefCell;
use std::rc::Rc;

fn main() {
    let value = Rc::new(RefCell::new(5));

    let a = Rc::new(
        Cons(
            Rc::clone(&value),
            Rc::new(Nil)
        )
    );

    let b = Cons(
        Rc::new(RefCell::new(3)),
        Rc::clone(&a)
    );
    let c = Cons(
        Rc::new(RefCell::new(4)),
        Rc::clone(&a)
    );

    *value.borrow_mut() += 10;

    println! ("之后的 a = {:?}", a);
    println! ("之后的 b = {:?}", b);
    println! ("之后的 c = {:?}", c);
}
