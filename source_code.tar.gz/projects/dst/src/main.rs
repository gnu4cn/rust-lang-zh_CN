fn main() {
    let s1: str = "致以问候！";
    let s2: str = "最近过得怎么样？";
}
