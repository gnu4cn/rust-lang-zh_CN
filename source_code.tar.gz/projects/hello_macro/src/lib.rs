pub trait HelloMacro {
    fn hello_macro();
}
