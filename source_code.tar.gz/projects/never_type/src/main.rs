fn main() {
    print! ("永永 ");

    loop {
        print! ("远远 ");
    }
}
