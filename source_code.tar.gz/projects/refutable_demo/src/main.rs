fn main() {
    if let x = 5 {
        println! ("{}", x);
    }
}
