fn do_something() {}

fn main() {
    for _i in 0..100 {
        do_something();
    }
}
