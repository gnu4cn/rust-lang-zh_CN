fn main() {
    let (x, y) = (1, 2, 3);

    // println! ("x: {}, y: {}, z: {}", x, y, z);
}
